package com.uni.productlab;

import android.net.Uri;

public class Product {
    public  String name;
    public  String detail;
    public Uri uri;
    public Product(String name,String detail,Uri uri){
        this.name = name;
        this.detail = detail;
        this.uri = uri;
    }
}
