package com.uni.productlab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("Login");
    }

    public void onClickLogin(View view) {
        String email = ((EditText)findViewById(R.id.email_log)).getText().toString();
        String password = ((EditText)findViewById(R.id.password_log)).getText().toString();

        FirebaseHelper.loginUser(this,email,password);
    }
}