package com.uni.productlab;

import static com.uni.productlab.FirebaseHelper.storageRef;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AddProductActivity extends AppCompatActivity {

    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        if(FirebaseHelper.firebaseAuth.getCurrentUser() != null){
            TextView loginid = findViewById(R.id.login_id);
            loginid.append(FirebaseHelper.firebaseAuth.getCurrentUser().getEmail());
        }

        getSupportActionBar().setTitle(R.string.studentID);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return true;
    }

    public void onClickMenu(MenuItem item) {
        if(item.getItemId() == R.id.list_menu){
            Intent intent = new Intent(this,ProductListActivity.class);
            startActivity(intent);
        }else if(item.getItemId() == R.id.logout_menu){
            FirebaseHelper.firebaseAuth.signOut();
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100 && data != null && data.getData() != null){
            uri = data.getData();

        }else if (requestCode == 2 && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            try {
                String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HHmmss").format(new Date());
                String imageFileName = "JPG_" + timeStamp + "_";
                File storageDir = getExternalFilesDir(null);
                File image = File.createTempFile(imageFileName,".jpg",storageDir);
                imageBitmap.compress(Bitmap.CompressFormat.JPEG,100, new FileOutputStream(image));
                uri = Uri.parse(image.getAbsolutePath());

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public void onClickUpload(View view){
        EditText nameEdittext = findViewById(R.id.add_product_name);
        EditText detailEdittext = findViewById(R.id.add_product_detail);
        Product product = new Product(nameEdittext.getText().toString(),detailEdittext.getText().toString(),uri);
        uploadProduct(product);
    }

    public void onClickPhoto(View view){
        if(view.getId() == R.id.cameraid){
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(takePictureIntent, 2);
        }else if(view.getId() == R.id.photoid){
            Intent intent = new Intent();
            intent.setType("image/");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(intent,100);
        }
    }

    public void uploadProduct(Product product) {
        Log.d("lab", product.uri.getLastPathSegment());
        String path = product.uri.getLastPathSegment();
        StorageReference storageReference = storageRef.child("img/" + path);
        storageReference.putFile(Uri.parse("file://" + product.uri)).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                storageReference.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        Uri uri = task.getResult();
                        Map<String, Object> productData = new HashMap<>();
                        productData.put("name", product.name);
                        productData.put("detail", product.detail);
                        productData.put("uri", uri.toString());


                        Log.d("lab", productData.toString());
                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        db.collection("Products").add(productData).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Toast.makeText(AddProductActivity.this, "Saved", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(AddProductActivity.this, ProductListActivity.class);
                                startActivity(intent);
                            }
                        });
                    }
                });


            }
        });
    }

}