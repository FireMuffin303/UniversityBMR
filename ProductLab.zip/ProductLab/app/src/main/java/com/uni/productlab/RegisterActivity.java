package com.uni.productlab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setTitle("Register");
    }

    public void onClickRegister(View view) {
        String email = ((EditText)findViewById(R.id.email_reg)).getText().toString();
        String password = ((EditText)findViewById(R.id.password_reg)).getText().toString();

        FirebaseHelper.registerUser(this,email,password);

    }
}