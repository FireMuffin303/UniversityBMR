package com.uni.productlab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(FirebaseHelper.firebaseAuth.getCurrentUser() != null){
            Intent intent = new Intent(this,ProductListActivity.class);
            startActivity(intent);
        }else{
            setContentView(R.layout.activity_main);
        }
    }

    public void onClick(View view) {
        Intent intent;
        if (view.getId() == R.id.registerbtn) {
            intent = new Intent(this, RegisterActivity.class);
        } else {
            intent = new Intent(this, LoginActivity.class);
        }
        startActivity(intent);
    }
}