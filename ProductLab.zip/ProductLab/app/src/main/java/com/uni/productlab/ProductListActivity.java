package com.uni.productlab;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProductListActivity extends AppCompatActivity {

    List<Product> products = new ArrayList<>();
    ProductAdapter productAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        getSupportActionBar().setTitle(R.string.studentID);
    }

    @Override
    protected void onStart() {
        refresh();
        super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return true;
    }

    public void onClickMenu(MenuItem item) {
        if(item.getItemId() == R.id.add_menu){
            Intent intent = new Intent(this,AddProductActivity.class);
            startActivity(intent);
        }else if(item.getItemId() == R.id.logout_menu){
            FirebaseHelper.firebaseAuth.signOut();
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        }
    }

    private void refresh(){
        products.clear();
        getProductFromFirebase();
        productAdapter = new ProductAdapter(this,products);
        ListView listView = findViewById(R.id.listview_product);
        listView.setAdapter(productAdapter);
    }

    public void getProductFromFirebase(){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Products").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for (QueryDocumentSnapshot document : task.getResult()){
                        String id = document.getId();
                        String name = (String) document.get("name");
                        String description = (String) document.get("detail");
                        String uri = (String) document.get("uri");
                        String path = Uri.parse(uri).getLastPathSegment();
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference(path);
                        try {
                            File localfile = File.createTempFile(path.replace("img/","").replace(".jpg",""),".jpg");
                            storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                                    Bitmap bitmap = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                                    Product product = new Product(name,description, Uri.parse(localfile.getAbsolutePath()));
                                    Log.d("lab",product.name);
                                    products.add(product);
                                    productAdapter.notifyDataSetChanged();
                                }
                            });
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

    }
}