package com.uni.productlab;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ProductAdapter extends ArrayAdapter<Product> {
    public ProductAdapter(@NonNull Context context, List<Product> products) {
        super(context, R.layout.list_item_activity,products);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Product product = getItem(position);
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_activity,parent,false);
        }

        TextView title = convertView.findViewById(R.id.textViewTitle);
        TextView detail = convertView.findViewById(R.id.textViewDetail);
        ImageView imageView = convertView.findViewById(R.id.imageViewProduct);
        title.setText(product.name);
        detail.setText(product.detail);
        imageView.setImageURI(product.uri);

        return convertView;
    }
}
