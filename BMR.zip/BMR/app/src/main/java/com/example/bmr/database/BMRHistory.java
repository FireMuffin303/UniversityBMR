package com.example.bmr.database;

public class BMRHistory {
    int id;
    float bmr;
    String datetime;

    public void setId(int id) {
        this.id = id;
    }

    public void setBmr(float bmr) {
        this.bmr = bmr;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public float getBmr() {
        return bmr;
    }

    public String getDatetime() {
        return datetime;
    }

    public int getId() {
        return id;
    }
}
