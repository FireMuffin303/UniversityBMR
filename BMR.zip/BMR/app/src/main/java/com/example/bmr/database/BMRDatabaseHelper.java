package com.example.bmr.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class BMRDatabaseHelper extends SQLiteOpenHelper {
    private String TABLENAME = "BMRHistory";

    public BMRDatabaseHelper(@Nullable Context context) {
        super(context, "BMRDatabase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_BMR_TABLE = "CREATE TABLE "+ TABLENAME +" (" +
                "id INTEGER PRIMARY KEY," +
                "bmr REAL NOT NULL," +
                "saveDate TEXT) ";
        sqLiteDatabase.execSQL(CREATE_BMR_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ TABLENAME);
        onCreate(sqLiteDatabase);
    }

    public void addBMRHistory(float bmr){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("bmr",bmr);

        String Datetime ="";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            Datetime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
        }
        values.put("saveDate",Datetime);

        db.insert("BMRHistory",null,values);
        db.close();
    }

    public List<BMRHistory> getAllBMRData(){
        List<BMRHistory> bmrHistoryList = new  ArrayList<BMRHistory>();
        String query = "SELECT * FROM "+TABLENAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query,null);

        if(cursor.moveToFirst()){
            do{
                BMRHistory bmrHistory = new BMRHistory();
                bmrHistory.setId(cursor.getInt(0));
                bmrHistory.setBmr(cursor.getFloat(1));
                bmrHistory.setDatetime(cursor.getString(2));
                bmrHistoryList.add(bmrHistory);
            }while(cursor.moveToNext());
        }

        return bmrHistoryList;
    }

    public void clearAllBMRData(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLENAME, null,null);
        db.close();

    }
}
