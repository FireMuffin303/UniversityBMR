package com.example.bmr;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bmr.database.BMRDatabaseHelper;
import com.example.bmr.database.BMRHistory;

import java.io.File;
import java.util.List;

public class DisplayResultActivity extends AppCompatActivity {
    String message;
    float result;
    private SharedPreferences sharedPreferences;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        setContentView(R.layout.activity_display);

        Intent intent = getIntent();
        String message = getString(R.string.bmr)+" "+ intent.getStringExtra(MainActivity.BMR_RESULT)+" " + getString(R.string.calories);
        this.result = Float.parseFloat(intent.getStringExtra(MainActivity.BMR_RESULT));
        this.message = message;

        ImageView imageView = findViewById(R.id.photo);
        String path = sharedPreferences.getString("PhotoPath", "");
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        imageView.setImageBitmap(bitmap);

// Set the text view with the message
        TextView textView = (TextView) findViewById(R.id.text_message);
        textView.setTextSize(25);
        textView.setText(message);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.calories_menu, menu);
        return true;
    }

    public void onClickShare(MenuItem item) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, message);
        sendIntent.setType("text/plain");

        Intent shareIntent = Intent.createChooser(sendIntent, null);
        startActivity(shareIntent);
    }

    public void onClickSave(MenuItem item){
        BMRDatabaseHelper bmrDatabaseHelper = new BMRDatabaseHelper(this);
        bmrDatabaseHelper.addBMRHistory(result);
        showDialogMessage(bmrDatabaseHelper.getAllBMRData());

    }

    public void showDialogMessage(List<BMRHistory> bmrHistoryList){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);

        String title = sharedPreferences.getString("history_title","").equals(getString(R.string.historydetails)) ? getString(R.string.historydetails) : sharedPreferences.getString("history_title","");
        builder.setTitle(title);

        int size;
        switch (sharedPreferences.getString("limithistory","")){
            case "1limit":
                size = bmrHistoryList.size() - 1;
                break;
            case "2limit":
                size = bmrHistoryList.size() - 2;
                break;
            case "3limit":
                size = bmrHistoryList.size() - 3;
                break;
            case "5limit":
                size = bmrHistoryList.size() - 5;
                break;
            default:
                size = 0;
                break;
        }

        String message= "";
        for(int i = bmrHistoryList.size()-1; i >= size;i--){
            String message1 = String.format("\n %s: %s \n %s: %.2f\n",getString(R.string.time),bmrHistoryList.get(i).getDatetime(),getString(R.string.bmr),bmrHistoryList.get(i).getBmr());
            message = String.format("%s %s",message,message1);
        }

        builder.setMessage(message);
        builder.show();
    }
}
